package javabeans;

public class candListBean {

}
